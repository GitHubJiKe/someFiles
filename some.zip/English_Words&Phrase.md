#day1
I am proud of you! 
我以你为傲！
It's a great opportunity of a lifetime! Make most of it!
这是你一生的机会，好好利用它！
Safe Journey!
一路平安！
Keep in touch!
保持联系！
****
#day 2
Excuse me,could you tell me the way to ...,
打扰一下，你能告诉我去...的路吗？
I wonder if you could help me please?
你能帮我一下吗？
Please could you give me directions to ...
你能给我指一下路吗？
I don't suppose you could show me the way, could you ?
我觉得你没办法给我指路了，对吧？
****
#day3
Could we set some ground rules?
我们能定一些规矩吗？
Would you mind keeping the room a bit more tidy?
你介不介意把房间保持整洁一些？
It would be great if I could have some space on the desk to put my things.
如果在桌子上能有给我放东西的地方，那可是帮了大忙了.
Would that be a reasonable compromise?
这样是不是一个合理的让步呢？
****
#day4
I'll have think about it.
我会考虑考虑的。
Sorry,I don't think I've got the time.
不好意思，我没时间。
It's not my cup of tea.
那可不是我的菜。
Great! Sign me up please.
太棒了，帮我签上名。
****
#day5
I'm really sorry but I'm not sure what to write.
很抱歉，我不知道怎么填这个表格。
Could you explain this form to me please?
能请你帮我解释一下这个表格吗？
I konw you're busy but I'd be greateful if you could help me.
我知道你很忙，但是如果你能帮我一下的话我会很感激。
Could I borrow a pen please?
我能借一只笔吗？
You look prettier in real life than you do in your passport photo.
你本人比护照上的照片好看多了。
****
#day6
Could you say that again please?
你能再说一遍吗？
Sorry,I don't understand what you mean.
对不起，我不懂你说什么意思。
Could you explain that in a different way please?
你能用别的方法解释一下吗？
****
#day7
Would you mind if I had a chance to speak please?
你介不介意给我个机会说两句？
I would like to say something too, if you don't mind.
你不介意的话，我也有些东西要说。
Thank you for giving me the chance to speak.
谢谢你给我机会让我能发言。
I'd like to contribute to the discussion please. 
我也想为讨论贡献力量。
****
#day 8
Please could you check if you have any of these books in stock?
请问您能帮我查一下这些书在书库里还有吗？
Could you reserve them for me please ?
请问你能帮我预定一下吗？
Could you put them by for me when they come in please?
这些书还回来的时候，你能帮我留一下吗？
When do you think they will be availavle?
你觉得神魔时候可以借到这些书？
****
# day 9
What a mess! 
真是一团糟！
Excuse me, can you tell me if you hanve any food suitable for vegetarians please?
不好意思，请问你能告诉我哪些食物适合素食者吃的吗？
Has this got meat in it?
这里面有肉吗？
Where can I find...?
我在哪能找到？
Do you have any...?
你有...吗?
****
# day 10
It's easier said than done.
说着容易做着难。
I need some more details before I begin my assignment please.
在我开始着手做我的作业之前，我希望了解更多的细节。
I really need to know the theme of the assignment.
我真的很需要知道作业的主题是什么。
How many words do you want ?
多少字要求？
How would you like it oresented?
你希望怎样呈现作业？
How should we deliver it to you when it's finished?
做完了怎么交给你？
When is the deadline for completing our assigment?
完成作业的截止日期是什么时候？
****
# day 11
I seem to have lost my work, what can I do ?
我好想弄丢了我的文件，我该怎么办？
Do you think you can restore my work please?
你觉得你能帮我恢复文件吗？
Is there anything you can do?
你能做些什么？

 